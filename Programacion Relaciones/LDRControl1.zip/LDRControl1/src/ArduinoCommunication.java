import com.fazecast.jSerialComm.SerialPort;

class ArduinoCommunication {
    private SerialPort comPort;

    public ArduinoCommunication() {
        // Busca el puerto serial disponible (asume que el Arduino está en el primer puerto)
        comPort = SerialPort.getCommPorts()[0];
        comPort.setBaudRate(9600);  // Configura la velocidad en baudios (debe coincidir con el código Arduino)
    }

    // Abre el puerto serial
    public void openConnection() {
        comPort.openPort();
    }

    // Cierra la conexión del puerto serial
    public void closeConnection() {
        comPort.closePort();
    }

    // Envia comandos al Arduino
    public void sendCommand(String command) {
        comPort.writeBytes(command.getBytes(), command.length());
    }

    // Lee los datos del puerto serial
    public String readData() {
        byte[] readBuffer = new byte[1024];
        int numRead = comPort.readBytes(readBuffer, readBuffer.length);

        if (numRead > 0) {
            return new String(readBuffer, 0, numRead).trim();  // Elimina los espacios en blanco
        }
        return "";
    }
}
