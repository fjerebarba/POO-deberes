import com.fazecast.jSerialComm.SerialPort;

class SensorLDR {
    private ArduinoCommunication arduinoComm;

    public SensorLDR(ArduinoCommunication arduinoComm) {
        this.arduinoComm = arduinoComm;
    }

    // Lee el valor del sensor LDR
    public int readLDRValue() {
        String value = arduinoComm.readData();
        try {
            return Integer.parseInt(value);  // Convierte el valor a entero
        } catch (NumberFormatException e) {
            System.out.println("Error al convertir el valor del LDR: " + value);
            return 0;
        }
    }
}
