import com.fazecast.jSerialComm.SerialPort;

class Button {
    private ArduinoCommunication arduinoComm;
    private String buttonCommand;

    public Button(ArduinoCommunication arduinoComm, String buttonCommand) {
        this.arduinoComm = arduinoComm;
        this.buttonCommand = buttonCommand;
    }

    // Verifica el estado del pulsador
    public void checkStatus() {
        arduinoComm.sendCommand(buttonCommand);
        String buttonStatus = arduinoComm.readData();
        
        if ("pressed".equals(buttonStatus)) {
            System.out.println("Pulsador presionado, apagando LED...");
            arduinoComm.sendCommand("0");  // Apagar LED
        } else {
            System.out.println("Pulsador no presionado");
        }
    }
}
