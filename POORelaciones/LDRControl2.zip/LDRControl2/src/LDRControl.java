import com.fazecast.jSerialComm.SerialPort;

public class LDRControl {
    public static void main(String[] args) {
        // Crea el objeto de comunicación con el Arduino
        ArduinoCommunication arduinoComm = new ArduinoCommunication();

        // Crea el objeto de sensor LDR
        SensorLDR ldrSensor = new SensorLDR(arduinoComm);

        // Crea el objeto de pulsadores
        Button button1 = new Button(arduinoComm, "checkButton1");
        Button button2 = new Button(arduinoComm, "checkButton2");

        // Inicia la comunicación
        arduinoComm.openConnection();

        // Bucle principal
        while (true) {
            // Lee el valor del sensor LDR
            int ldrValue = ldrSensor.readLDRValue();

            // Controla los LEDs en base al valor del LDR
            if (ldrValue > 700) {
                arduinoComm.sendCommand("0");  // Apagar LEDs
            } else {
                arduinoComm.sendCommand("1");  // Encender LEDs
            }

            // Verifica el estado de los pulsadores
            button1.checkStatus();
            button2.checkStatus();

            // Espera antes de realizar la siguiente iteración
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}